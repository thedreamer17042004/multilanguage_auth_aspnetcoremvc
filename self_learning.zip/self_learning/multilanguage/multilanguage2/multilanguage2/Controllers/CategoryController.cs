﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;

namespace multilanguage2.Controllers
{
    public class CategoryController : Controller
    {
        private readonly IStringLocalizer<CategoryController> _localizer;
        public CategoryController(IStringLocalizer<CategoryController> localizer)
        {
            _localizer = localizer;
        }


        [HttpGet]
        public IActionResult Index()
        {
            var data = _localizer["categorypage"];
            ViewBag.data = data;
            return View();
        }
    }
}
