Create database Authentication_aspcore
go
use Authentication_aspcore

go
Create table Account(
    AccountId varchar(36) primary key,
    Username varchar(32),
    Password varchar(256),
    Email varchar(128),
    Fullname nvarchar(64)
);
go
insert into Account(NEWID(), 'namnv', lower(convert(varchar(32), HashBytes('md5', '123456'), 2)), 'nam@gmail.com', 'Van nam')