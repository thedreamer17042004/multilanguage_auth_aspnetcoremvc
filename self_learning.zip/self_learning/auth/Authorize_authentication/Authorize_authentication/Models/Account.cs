﻿using System;
using System.Collections.Generic;

namespace Authorize_authentication.Models;

public partial class Account
{
    public string AccountId { get; set; } = null!;

    public string? Username { get; set; }

    public string? Password { get; set; }

    public string? Email { get; set; }

    public string? Fullname { get; set; }
}
