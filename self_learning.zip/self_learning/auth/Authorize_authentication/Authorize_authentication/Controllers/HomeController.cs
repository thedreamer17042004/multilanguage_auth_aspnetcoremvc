﻿using Microsoft.AspNetCore.Mvc;

namespace Authorize_authentication.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
