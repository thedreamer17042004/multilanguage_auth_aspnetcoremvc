using Authorize_authentication.Models;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.EntityFrameworkCore;
using System.Configuration;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();


builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.ExpireTimeSpan = TimeSpan.FromMinutes(20);
        options.SlidingExpiration = true;
        options.AccessDeniedPath = "/Forbidden/";
        options.LoginPath = "/Admin/Login";
    });

builder.Services.AddDbContext<AuthenticationAspcoreContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("AuthenticationAspcoreContext")));

// Add a reference to the Startup class
builder.Services.AddRazorPages().AddApplicationPart(typeof(Authorize_authentication.Startup).Assembly);

var app = builder.Build();

// Configure the HTTP request pipeline.
var startup = new Authorize_authentication.Startup(builder.Configuration);
startup.Configure(app, builder.Environment);

app.Run();
