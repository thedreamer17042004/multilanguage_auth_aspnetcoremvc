﻿using Authorize_authentication.Areas.Admin.Models;
using Authorize_authentication.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace Authorize_authentication.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize]
    public class HomeController : Controller
    {
        private readonly AuthenticationAspcoreContext _context;

        public HomeController(AuthenticationAspcoreContext db)
        {
            this._context = db;
        }

        public IActionResult Index()
        {
            return View();
        }


        [HttpGet("/Admin/Login")]
        [AllowAnonymous]
        public IActionResult Login()
        {
            return View();
        }


        [HttpPost]
        [AllowAnonymous]
        public IActionResult Login(string username, string password)
        {
            Console.WriteLine("vào đây ");
            var hashPassword = Utility.MD5Hash(password);
            var acc = _context.Accounts.FirstOrDefault(x=>x.Username == username && x.Password == hashPassword);
            if (acc != null)
            {
                var identity = new ClaimsIdentity(
                [
                    new Claim(ClaimTypes.Name, acc.Username),
                    new Claim(ClaimTypes.GivenName, acc.Fullname)
                ], "login");

                //  HttpContext.Session.SetString("Picture", acc.Fullname);
                var principle = new ClaimsPrincipal(identity);

                var login = HttpContext.SignInAsync(principle);

                return Redirect("~/Admin/Home/Index");

            }else
            {
                ViewBag.error = "<div class='alert alert-danger'>Đăng nhập sai</div>";
                return View();
            }
           
        }


        [HttpGet("/Admin/Home/Logout")]
        [AllowAnonymous]
        public IActionResult Logout()
        {
            HttpContext.SignOutAsync();
            return Redirect("~/Admin/Home/Index");

        }

    }
}
